package edu.harvard.med.open;

public interface Command {
    public String perform();
    
    public void close();
}