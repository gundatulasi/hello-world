package excerises;

import static edu.harvard.med.open.Util.set;

import static edu.harvard.med.open.Util.asSet;
import static edu.harvard.med.open.Util.ival;
import static edu.harvard.med.open.Util.list;
import static edu.harvard.med.open.Util.set;

import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S521650
 */
public final class ExercisesTest{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          Exercises exercises = new Exercises();

         String s =  exercises.censor("Hello world how's it going ?", set("world", "it", "going"));
         System.out.println( s );
         
         
         System.out.println("Is palindrome: "+ exercises.isPalindrome("Able was I ere i saw Elba"));
         
         System.out.println("Pascal number is: "+ exercises.pascal(1 ,0) );
         
         
         
         
         
         
    //@Test
//    public void testCensor() {
//        assertEquals("", exercises.censor("", Util.<String>set()));
//      //  assertEquals("", exercises.censor("", set("foo", "bar")));
//
//        try {
//            exercises.censor(null, Util.<String>set());
//
//            fail("Should have thrown");
//        } catch (IllegalArgumentException expected) {}
//
//        try {
//            exercises.censor("", null);
//
//            fail("Should have thrown");
//        } catch (IllegalArgumentException expected) {}
//
//        {
//            final String helloWorld = "Hello world how's it going ?";
//
//            assertEquals(helloWorld, exercises.censor(helloWorld, Util.<String>set()));
//
//            assertEquals(helloWorld, exercises.censor(helloWorld, set("foo", "bar")));
//
//            assertEquals("Hello ***** how's it going ?", exercises.censor(helloWorld, set("world")));
//
//            assertEquals("Hello ***** how's ** ***** ?", exercises.censor(helloWorld, set("world", "it", "going")));
//
//            assertEquals("***** ***** how's ** ***** ?", exercises.censor(helloWorld, set("hello", "world", "it", "going")));
//        }
//    }
//    
    }
    
}
